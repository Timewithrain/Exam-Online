package com.LHF.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class DatabaseConnection {
	Connection connection = null;
	PreparedStatement preparedStatement = null;
	ResultSet rs = null;
	
	JSONArray jsonArray = new JSONArray();
	JSONObject json = null;
	
	public DatabaseConnection(){
		
	}
	
	public JSONArray createJson() {
		try{
			String sql = "select * from a";
			preparedStatement = connection.prepareStatement(sql);
			if(preparedStatement.execute()) {
				rs = preparedStatement.getResultSet();
				while(rs.next()){
					json = new JSONObject();
					json.put("num", rs.getInt("num"));
					json.put("timu", rs.getString("timu"));
					json.put("A", rs.getString("A"));
					json.put("B", rs.getTimestamp("B"));
					json.put("C", rs.getString("C"));
					json.put("D", rs.getTimestamp("D"));
					json.put("right", rs.getString("right"));
					json.put("selection", rs.getTimestamp("selection"));
					json.put("grade", rs.getInt("grade"));
					jsonArray.add(json);
				}
			}
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			//关闭连接
			
			try{
				rs.close();
			}catch(SQLException e){
				e.printStackTrace();
			}
			try{
				preparedStatement.close();
			}catch(SQLException e){
				e.printStackTrace();
			}
			try{
				connection.close();
			}catch(SQLException e){
				e.printStackTrace();
			}
		}
		return jsonArray;
	}
	
	public void database() {
		try{
			Class.forName("com.mysql.jdbc.Driver");//加载驱动
			String url = "jdbc:mysql://localhost:3306/luohuan?user=root&password=root";
			connection = DriverManager.getConnection(url);//连接数据库
		}catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch(NullPointerException e){
			e.printStackTrace();
		}
	}


}
